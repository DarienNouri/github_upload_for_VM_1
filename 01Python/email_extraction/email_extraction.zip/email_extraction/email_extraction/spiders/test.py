x = 5

if x == 5:
    y = x

    print(y)
